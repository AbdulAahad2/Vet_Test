from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError


class LandedCostLineCalculation(models.Model):
    _name = 'landed.cost.line.calculation'
    _description = 'Landed Cost Line Calculation Detail'
    _order = 'sequence, id'

    landed_cost_id = fields.Many2one('stock.landed.cost', string='Landed Cost', required=True, ondelete='cascade')
    valuation_adjustment_line_id = fields.Many2one('stock.valuation.adjustment.lines', string='Valuation Line', ondelete='cascade')
    
    sequence = fields.Integer(string='Sequence', default=10)
    product_id = fields.Many2one('product.product', string='Product', required=True)
    
    # Original values from Odoo
    original_cost = fields.Float(string='Original Product Cost', digits='Product Price')
    
    # Calculation fields for each landed cost
    cost_line_id = fields.Many2one('stock.landed.cost.lines', string='Cost Line')
    cost_line_name = fields.Char(string='Cost Description', related='cost_line_id.name', store=True)
    cost_amount = fields.Float(string='Cost Amount', digits='Product Price')
    cost_percentage = fields.Float(string='Cost %', digits=(16, 2))
    
    # Base amount for calculation (can be overridden)
    base_amount = fields.Float(string='Auto Base', digits='Product Price', 
                               help='The automatic base amount (running total from previous LC)')
    
    # Manual override selection
    use_custom_base = fields.Boolean(string='Use Custom Base', default=False,
                                     help='Check this to apply percentage to a different LC total instead of the previous running total')
    
    custom_base_calc_id = fields.Many2one('landed.cost.line.calculation', 
                                          string='Apply % to LC',
                                          help='Select which previous LC total to use for percentage calculation',
                                          domain="[('id', '<', id), ('landed_cost_id', '=', landed_cost_id), ('product_id', '=', product_id)]")
    
    custom_base_amount = fields.Float(string='Custom Base Amount', 
                                      compute='_compute_custom_base_amount',
                                      store=True,
                                      digits='Product Price',
                                      help='The running total from the selected LC')
    
    # Previous running total (always from immediate previous LC)
    previous_running_total = fields.Float(string='Previous Total', digits='Product Price',
                                         help='Running total from immediate previous LC - this is where we add the calculated cost')
    
    # Calculated amount
    calculated_cost = fields.Float(string='Calculated Cost', 
                                   compute='_compute_calculated_cost', 
                                   store=True, 
                                   digits='Product Price',
                                   help='The cost calculated from percentage')
    
    # Running total after this cost
    running_total = fields.Float(string='Running Total', digits='Product Price',
                                 help='Cumulative product cost after applying this landed cost')
    
    # Final values
    final_cost = fields.Float(string='Final Unit Cost', digits='Product Price')
    quantity = fields.Float(string='Quantity', digits='Product Unit of Measure')

    @api.depends('custom_base_calc_id', 'custom_base_calc_id.running_total')
    def _compute_custom_base_amount(self):
        for rec in self:
            if rec.custom_base_calc_id:
                rec.custom_base_amount = rec.custom_base_calc_id.running_total
            else:
                rec.custom_base_amount = 0.0

    @api.depends('base_amount', 'custom_base_amount', 'use_custom_base', 'cost_percentage', 'cost_amount', 'previous_running_total')
    def _compute_calculated_cost(self):
        for rec in self:
            # Determine which base to use for percentage calculation
            if rec.use_custom_base and rec.custom_base_amount:
                calc_base = rec.custom_base_amount
            else:
                calc_base = rec.base_amount
            
            # Calculate the cost from percentage
            if rec.cost_percentage:
                rec.calculated_cost = calc_base * (rec.cost_percentage / 100.0)
            else:
                rec.calculated_cost = rec.cost_amount

    @api.onchange('use_custom_base', 'custom_base_calc_id')
    def _onchange_custom_base(self):
        """Recalculate when custom base is changed"""
        if self.use_custom_base and self.custom_base_calc_id:
            if self.cost_percentage:
                self.calculated_cost = self.custom_base_calc_id.running_total * (self.cost_percentage / 100.0)

    @api.onchange('cost_percentage')
    def _onchange_cost_percentage(self):
        """Auto-recalculate when % changes"""
        if self.cost_percentage and self.landed_cost_id:
            self.landed_cost_id.recalculate_with_custom_bases()

    @api.constrains('custom_base_calc_id', 'sequence')
    def _check_custom_base_sequence(self):
        """Ensure custom base is from a previous LC only"""
        for rec in self:
            if rec.custom_base_calc_id:
                if rec.custom_base_calc_id.sequence >= rec.sequence:
                    raise ValidationError(
                        f"You can only select previous Landed Costs as base. "
                        f"'{rec.cost_line_name}' cannot use '{rec.custom_base_calc_id.cost_line_name}' as base."
                    )

    def write(self, vals):
        """Trigger recalculation when calculation lines are modified"""
        res = super().write(vals)
        if any(key in vals for key in ['use_custom_base', 'custom_base_calc_id', 'cost_percentage']):
            # Trigger recalculation for the entire landed cost
            landed_costs = self.mapped('landed_cost_id')
            for lc in landed_costs:
                lc.recalculate_with_custom_bases()
        return res
