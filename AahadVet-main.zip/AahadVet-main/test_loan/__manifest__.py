{
    'name': 'Advanced Landed Cost Calculator',
    'version': '18.0.1.0.0',
    'category': 'Inventory/Inventory',
    'summary': 'Advanced landed cost with custom calculation sequence',
    'description': """
        This module extends the standard landed cost functionality to allow:
        - Visual table showing all landed cost calculations
        - Manual override of calculation base amounts
        - Non-linear landed cost application
        - Flexible percentage application on different base amounts
    """,
    'author': 'Your Company',
    'website': 'https://www.yourcompany.com',
    'depends': ['stock_landed_costs'],
    'data': [
        'security/ir.model.access.csv',
        'views/stock_landed_cost_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}