/** @odoo-module **/
import { Component } from "@odoo/owl";
import { Dialog } from "@web/core/dialog/dialog";
import { useState } from "@odoo/owl";
import { usePos } from "@point_of_sale/app/store/pos_hook";

export class WkDiscountPopup extends Component {
    static template = "pos_custom_discounts.WkDiscountPopup";
    static components = { Dialog };

    static props = {
        title: { type: String, optional: true },
        discounts: Array,
        selectedLine: { type: Object, optional: false },
        getPayload: { type: Function, optional: true },
        close: Function,
    };

    setup() {
        const selectedDiscountObj = this.props.selectedLine.selected_list_discount || null;
        const hasLineDiscount = this.props.selectedLine.get_discount() > 0; // check if line has discount %
        this.pos = usePos();

        this.state = useState({
            selectedDiscount: selectedDiscountObj,
            showFixedDiscount: !(selectedDiscountObj === null && hasLineDiscount),
            discountAmount: (selectedDiscountObj === null && hasLineDiscount)
        ? (this.props.selectedLine.get_discount() / 100) *
          (this.props.selectedLine.get_price_with_tax_before_discount())
        : null,
        });
    }

    selectDiscount(discount) {
        this.state.selectedDiscount = discount;
    }

    click_apply() {
        if (this.state.showFixedDiscount) {
            // ✅ FIXED DISCOUNT FLOW
            if (this.state.selectedDiscount) {
                this.props.getPayload({ scope: "line", discount: this.state.selectedDiscount });
                this.props.close();
            }
        } else {
            // ✅ DISCOUNT BY AMOUNT FLOW (LINE LEVEL)
            const amount = parseFloat(this.state.discountAmount) || 0;
            if (amount <= 0) {
                alert("Please enter a valid discount amount greater than 0.");
                return;
            }
            const lineAmount = this.props.selectedLine.get_price_with_tax_before_discount(); // POS line amount
            if (amount >= lineAmount) {
                alert("Discount amount must be less than the line total.");
                return;
            }
            const discountPercent = (amount / lineAmount) * 100;
//            Here we have amount. we have to calculate the discount number so that in result it gives the discount = amount
            this.props.getPayload({ scope: "line-amount", discount: discountPercent });
            this.props.close();
        }
    }

    click_apply_complete_order() {
        if (this.state.showFixedDiscount) {
            // ✅ FIXED DISCOUNT FLOW
            if (this.state.selectedDiscount) {
                this.props.getPayload({ scope: "order", discount: this.state.selectedDiscount });
                this.props.close();
            }
        } else {
            // ✅ DISCOUNT BY AMOUNT FLOW (ORDER LEVEL)
            const amount = parseFloat(this.state.discountAmount) || 0;
            if (amount <= 0) {
                alert("Please enter a valid discount amount greater than 0.");
                return;
            }
            let totalOrderlineAmount = 0;

            const orderlines = this.pos.get_order().get_orderlines(); // POS order total

             for (const line of orderlines) {
                        totalOrderlineAmount += line.get_price_with_tax();
             }
            const orderAmount = this.props.selectedLine.order_id.get_total_with_tax(); // POS order total
            if (amount >= orderAmount) {
                alert("Discount amount must be less than the order total.");
                return;
            }
            const discountPercent = (amount / orderAmount) * 100;

            this.props.getPayload({ scope: "order-amount", discount: discountPercent,discountAmount:amount });
            this.props.close();
        }
    }

    click_remove_discount() {
        this.props.getPayload({ scope: "line-remove" });
        this.props.close();
    }
    click_remove_all_discount() {
        this.props.getPayload({ scope: "order-remove" });
        this.props.close();
    }
}
