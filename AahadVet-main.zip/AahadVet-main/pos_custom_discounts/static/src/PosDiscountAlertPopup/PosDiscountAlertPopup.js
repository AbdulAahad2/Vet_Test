/** @odoo-module **/
import { Component } from "@odoo/owl";
import { Dialog } from "@web/core/dialog/dialog";


export class PosDiscountAlertPopup extends Component {
    static template = "pos_custom_discounts.PosDiscountAlertPopup";
    static components = { Dialog };

    static props = {
        title: String,  // Add message prop
        message: String,  // Add message prop
        getPayload: Function,
        close: Function,
    };
    setup() {
        super.setup();
    }


    onClose() {
        this.props.close();
    }
    confirm() {
        const payload = {
            productName: this.props.product.display_name
        };
        this.props.getPayload(payload);
        this.props.close();
    }
}
