
import { OrderSummary } from "@point_of_sale/app/screens/product_screen/order_summary/order_summary";
import { _t } from "@web/core/l10n/translation";
import { makeAwaitable } from "@point_of_sale/app/store/make_awaitable_dialog";
import { SelectionPopup } from "@point_of_sale/app/utils/input_popups/selection_popup";
import { patch } from "@web/core/utils/patch";
import { WkDiscountPopup } from "@pos_custom_discounts/WkDiscountPopup/WkDiscountPopup";

patch(OrderSummary.prototype, {

         setup() {
        super.setup(...arguments);
    },
    async updateSelectedOrderline({ buffer, key }) {
        if (this.pos.numpadMode === "discount" && this.currentOrder) {
                const selectedLine = this.currentOrder.get_selected_orderline();

                 const result = this.dialog.add(WkDiscountPopup, {
        title: _t("POS Custom Discounts"),
        discounts: pos_custom_discounts,
        selectedLine: selectedLine,
        getPayload: (payload) => {

        const curOrder = this.pos.get_order();
        const line = curOrder.get_selected_orderline();
        if (payload?.scope === "line" && payload.discount && line) {
                    const pct = parseFloat(payload.discount.discount_percent) || 0;
                    line.set_discount(pct);
                        line.set_selected_list_discount(payload.discount.id);
                        line.selected_list_discount=payload.discount;
                } else if (payload?.scope === "order" && payload.discount) {
                    const pct = parseFloat(payload.discount.discount_percent) || 0;
                    for (const l of curOrder.get_orderlines()) {
                        l.set_discount(pct);
                        l.selected_list_discount=payload.discount;

                    }
                    curOrder.save_to_db && curOrder.save_to_db();
                } else if (payload?.scope === "remove" && line) {
                    line.set_discount(0);
                    line.selected_list_discount = false;
                }





        }

                });



        }else{
        return super.updateSelectedOrderline({ buffer, key });
        }


    },





});
