/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { ControlButtons } from "@point_of_sale/app/screens/product_screen/control_buttons/control_buttons";
import { SelectCreateDialog } from "@web/views/view_dialogs/select_create_dialog";
import { _t } from "@web/core/l10n/translation";
import { makeAwaitable } from "@point_of_sale/app/store/make_awaitable_dialog";
import { useService } from "@web/core/utils/hooks";
import { ask } from "@point_of_sale/app/store/make_awaitable_dialog";
import { Dialog } from "@web/core/dialog/dialog";
import { useAsyncLockedMethod } from "@point_of_sale/app/utils/hooks";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { ConfirmationDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
import { WkDiscountPopup } from "@pos_custom_discounts/WkDiscountPopup/WkDiscountPopup";
import { PosDiscountAlertPopup } from "@pos_custom_discounts/PosDiscountAlertPopup/PosDiscountAlertPopup";

patch(ControlButtons.prototype, {
    setup() {
        super.setup(...arguments)
        this.printer = useService("printer");
        this.orm = useService("orm");
        this.pos = usePos();
        this.dialog = useService("dialog");
    },

    onClickShowCustomDiscountPopup(){

    const pos_custom_discounts = this.pos.models["pos.custom.discount"].getAll();
        const currentOrder = this.pos.get_order();
        const selectedLine = currentOrder.get_selected_orderline();
        const cashier = this.pos.get_cashier()
        const amount_before_discount = this.pos.get_order().amount_total
//                    if(cashier._role=='manager'){
                     const result = this.dialog.add(WkDiscountPopup, {
                        title: _t("POS Custom Discounts"),
                        discounts: pos_custom_discounts,
                        selectedLine: selectedLine,
                        getPayload: (payload) => {

                        const curOrder = this.pos.get_order();

                        const line = curOrder.get_selected_orderline();

                        if (payload?.scope === "line" && payload.discount && line) {
                        const pct = parseFloat(payload.discount.discount_percent) || 0;
                            line.set_discount(pct);
                            line.set_selected_list_discount(payload.discount.id);
                            line.selected_list_discount=payload.discount;
                            } else if (payload?.scope === "order" && payload.discount) {
                                const pct = parseFloat(payload.discount.discount_percent) || 0;
                                for (const l of curOrder.get_orderlines()) {
                                    l.set_discount(pct);
                                    l.set_selected_list_discount(payload.discount.id);
                                    l.selected_list_discount=payload.discount;
                                }
                            }else if (payload?.scope === "line-amount" && line) {
                                line.set_discount(payload?.discount);
                                line.selected_list_discount = false;
                            }else if (payload?.scope === "order-amount" && payload.discount) {
                                const pct = parseFloat(payload?.discount) || 0;
                                const discountAmount = payload.discountAmount

                                for (const l of curOrder.get_orderlines()) {
                                    l.set_discount(pct);
                                    console.log('PCT',pct)
                                    l.set_selected_list_discount(false);
                                    l.selected_list_discount=false;

                                }

//                                get the amount of the order after applying discount
                                const amount_after_discount = this.pos.get_order().amount_total
                                const theoratical_discounted_amount = amount_before_discount-discountAmount
                                    console.log('amount_before_discount',amount_before_discount)
                                    console.log('discountAmount',discountAmount)

                                    console.log('theoratical_discounted_amount',theoratical_discounted_amount)
                                    console.log('amount_after_discount',amount_after_discount)

                            }else if (payload?.scope === "line-remove" && line) {
                                line.set_discount(0);
                                line.set_selected_list_discount(false);
                                line.selected_list_discount = false;
                            }else if (payload?.scope === "order-remove" && line) {
                                for (const l of curOrder.get_orderlines()) {
                                    l.set_discount(0);
                                    l.set_selected_list_discount(false);
                                    l.selected_list_discount=false;

                                }
                            }

                        }

                      });

//                    }else{
//
//                            this.pos.dialog.add(PosDiscountAlertPopup, {
//                            title: _t("POS Discount Restrictions"),
//                            message: ('Sorry, You Are Not Allowed To give Discounts, Please Contact the Manager.'),
//                            getPayload: (payload) => {
//                                console.log("Popup Payload");
//                                },
//                            });
//
//
//
//
//
//                    }






    }


});
