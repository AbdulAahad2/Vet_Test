// Part of Odoo. See LICENSE file for full copyright and licensing details.
import { PosOrderline } from "@point_of_sale/app/models/pos_order_line";
import { Orderline } from "@point_of_sale/app/generic_components/orderline/orderline";
import { patch } from "@web/core/utils/patch";
import { Dialog } from "@web/core/dialog/dialog";
import { Component, useState, xml } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { SelectionPopup } from "@point_of_sale/app/utils/input_popups/selection_popup";
import { makeAwaitable } from "@point_of_sale/app/store/make_awaitable_dialog";
import { _t } from "@web/core/l10n/translation";
import { usePos } from "@point_of_sale/app/store/pos_hook";

patch(PosOrderline.prototype, {
    setup(vals) {
        super.setup(...arguments);
                this.selected_list_discount_id = vals.selected_list_discount_id || false;
    },

    getDisplayData() {
        const result = super.getDisplayData(...arguments);
        if(this.selected_list_discount_id){
            result["selected_list_discount_id"] = String(this.selected_list_discount_id);
        }else{
        result["selected_list_discount_id"] =''
        }
        if(this.get_price_with_tax_before_discount() ){
            result["get_price_with_tax_before_discount"] = String(this.get_price_with_tax_before_discount());
        }else{
        result["get_price_with_tax_before_discount"] =''
        }

        return result
    },


    get_selected_list_discount(){

     return this.selected_list_discount_id

    },
    set_selected_list_discount(selected_list_discount_id) {
        this.selected_list_discount_id = selected_list_discount_id;
    },

});



patch(Orderline, {
    props: {
        ...Orderline.props,
        line: {
            ...Orderline.props.line,
            shape: {
                ...Orderline.props.line.shape,
                get_price_with_tax_before_discount: { type: String, optional: true },
                selected_list_discount_id: { type: String, optional: true },
            },
        },
    },
});





patch(Orderline.prototype, {
     setup() {
        super.setup(...arguments);
        this.pos = usePos();
    },

});

