import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { patch } from "@web/core/utils/patch";
import { onMounted } from "@odoo/owl";
import { WkDiscountPopup } from "@pos_custom_discounts/WkDiscountPopup/WkDiscountPopup";
import { _t } from "@web/core/l10n/translation";
import { PosDiscountAlertPopup } from "@pos_custom_discounts/PosDiscountAlertPopup/PosDiscountAlertPopup";

patch(ProductScreen.prototype, {
    setup() {
        super.setup(...arguments);
    },

    onNumpadClick(buttonValue) {
        if (["quantity", "discount", "price"].includes(buttonValue)) {
                const cashier = this.pos.get_cashier()
                if(["discount"].includes(buttonValue) && this.pos.config.allow_custom_discount && this.pos.config.discount_ids){
                    const pos_custom_discounts = this.pos.models["pos.custom.discount"].getAll();

                const currentOrder = this.currentOrder;
                const selectedLine = currentOrder.get_selected_orderline();
                if(!selectedLine){
                    console.log('No Orderline')
                }else
                {
//                    if(cashier._role=='manager'){

                    const result = this.dialog.add(WkDiscountPopup, {
                    title: _t("POS Custom Discounts"),
                    discounts: pos_custom_discounts,
                    selectedLine: selectedLine,
                    getPayload: (payload) => {
                    const curOrder = this.pos.get_order();

                    const line = curOrder.get_selected_orderline();

                        if (payload?.scope === "line" && payload.discount && line) {
                        const pct = parseFloat(payload.discount.discount_percent) || 0;
                            line.set_discount(pct);
                            line.set_selected_list_discount(payload.discount.id);
                            line.selected_list_discount=payload.discount;
                    } else if (payload?.scope === "order" && payload.discount) {
                        const pct = parseFloat(payload.discount.discount_percent) || 0;
                        for (const l of curOrder.get_orderlines()) {
                            l.set_discount(pct);
                            l.set_selected_list_discount(payload.discount.id);
                            l.selected_list_discount=payload.discount;

                        }
                    }else if (payload?.scope === "line-amount" && line) {
                        line.set_discount(payload?.discount);
                        line.selected_list_discount = false;
                    }else if (payload?.scope === "order-amount" && payload.discount) {
                        const pct = parseFloat(payload?.discount) || 0;
                        for (const l of curOrder.get_orderlines()) {
                            l.set_discount(pct);
                            l.set_selected_list_discount(false);
                            l.selected_list_discount=false;

                        }
                    }else if (payload?.scope === "line-remove" && line) {
                        line.set_discount(0);
                        line.set_selected_list_discount(false);
                        line.selected_list_discount = false;
                    }else if (payload?.scope === "order-remove" && line) {
                        for (const l of curOrder.get_orderlines()) {
                            l.set_discount(0);
                            l.set_selected_list_discount(false);
                            l.selected_list_discount=false;

                        }
                    }



                    }

                    });


//                    }else{
//
//                            this.pos.dialog.add(PosDiscountAlertPopup, {
//                            title: _t("POS Discount Restrictions"),
//                            message: ('Sorry, You Are Not Allowed To give Discounts, Please Contact the Manager.'),
//                            getPayload: (payload) => {
//                                console.log("Popup Payload");
//                                },
//                            });
//
//
//                    }


                }

                }else
                {
                    this.numberBuffer.capture();
                    this.numberBuffer.reset();
                    this.pos.numpadMode = buttonValue;
                    return;
                }


        }

        this.numberBuffer.sendKey(buttonValue);
    }






});
