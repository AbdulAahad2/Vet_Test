/** @odoo-module */


import { PosStore } from "@point_of_sale/app/store/pos_store";
import { patch } from "@web/core/utils/patch";
import { rpc } from "@web/core/network/rpc";

import {
    deduceUrl,
    lte,
    random5Chars,
    uuidv4,
    computeProductPricelistCache,
} from "@point_of_sale/utils";

patch(PosStore.prototype, {
    // @Override
    async setup() {
        await super.setup(...arguments);
    },
    async _processData(loadedData) {
        super._processData(loadedData)
        this.pos_custom_discounts = loadedData["pos.custom.discount"]
    },


});

