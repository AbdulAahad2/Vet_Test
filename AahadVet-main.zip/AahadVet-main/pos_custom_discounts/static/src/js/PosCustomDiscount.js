import { registry } from "@web/core/registry";
import { Base } from "@point_of_sale/app/models/related_models";

const { DateTime } = luxon;

export class PosCustomDiscountModel extends Base {
    static pythonModel = "pos.custom.discount";
}

registry.category("pos_available_models").add(PosCustomDiscountModel.pythonModel, PosCustomDiscountModel);
