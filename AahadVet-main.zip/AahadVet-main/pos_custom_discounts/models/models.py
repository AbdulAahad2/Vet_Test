# -*- coding: utf-8 -*-
#################################################################################
#
#   Copyright (c) 2016-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#   See LICENSE file for full copyright and licensing details.
#   License URL : <https://store.webkul.com/license.html/>
# 
#################################################################################
from odoo import api, fields, models
from odoo.exceptions import ValidationError


class POsCustomDiscount(models.Model):
    _name = "pos.custom.discount"
    _inherit = ['pos.load.mixin']

    _description = "Pos Custom Discounts"

    name = fields.Char(string="Name", required=1)
    discount_percent = fields.Float(string="Discount Percentage", required=1)
    description = fields.Text(string="Description")
    available_in_pos = fields.Many2many('pos.config', string="Available In Pos")

    @api.model
    def _load_pos_data_fields(self, config_id):
        return ['id', 'name', 'discount_percent', 'description', 'available_in_pos']

    @api.constrains('discount_percent')
    def check_validation_discount_percent(self):
        """This is to validate discount percentage"""
        if self.discount_percent <= 0 or self.discount_percent > 100:
            raise ValidationError("Discount percent must be between 0 and 100.")


    def _load_pos_data(self, data):
        config_id = data['pos.config']['data'][0]['id']
        domain = self._load_pos_data_domain(data)
        fields = self._load_pos_data_fields(config_id)

        # Step 2: Load parent records (main model)
        parent_records = self.with_context({**self.env.context}).search_read(domain, fields, load=False)

        dependent_value_ids = set()

        for rec in parent_records:
            dependent_value_ids.update(rec.get('available_in_pos', []))

        dependent_value_records = []
        if dependent_value_ids:
            dependent_value_records = self.env['pos.config'].search_read(
                [('id', 'in', list(dependent_value_ids))]
            )

        return {
            'data': parent_records,
            'fields': fields,
            'available_in_pos': dependent_value_records  # One2many related data

        }


class PosConfig(models.Model):
    _inherit = 'pos.config'

    discount_ids = fields.Many2many('pos.custom.discount', string="Discounts")
    allow_custom_discount = fields.Boolean('Allow Customize Discount', default=True)
    allow_security_pin = fields.Boolean('Allow Security Pin')




class PosSessionInherited(models.Model):
    _inherit = 'pos.session'


    @api.model
    def _load_pos_data_models(self, config_id):
        data = super()._load_pos_data_models(config_id)

        data += ['pos.custom.discount']
        return data

class PosOrderLine(models.Model):
    _inherit = 'pos.order.line'
    custom_discount_reason = fields.Text('Discount Reason')
    selected_list_discount_id = fields.Many2one('pos.custom.discount',string='Selected Discount')



    @api.model
    def _load_pos_data_fields(self, config_id):
        fields = super()._load_pos_data_fields(config_id)
        fields += ['custom_discount_reason','selected_list_discount_id']
        return fields


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    discount_ids = fields.Many2many(related='pos_config_id.discount_ids',readonly=True)
    allow_custom_discount = fields.Boolean(related='pos_config_id.allow_custom_discount',readonly=False)
    allow_security_pin = fields.Boolean(related='pos_config_id.allow_security_pin',readonly=False)

