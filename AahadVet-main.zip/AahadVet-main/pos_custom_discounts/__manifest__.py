# -*- coding: utf-8 -*-
#################################################################################
# Author      : Webkul Software Pvt. Ltd. (<https://webkul.com/>)
# Copyright(c): 2015-Present Webkul Software Pvt. Ltd.
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <https://store.webkul.com/license.html/>
#################################################################################
{
    "name": "POS Custom Discount",
    "summary": """This module allows the seller to apply discount on single product as well as complete order in pos session.Order Discount|Discount on Products|Discounted Products.""",
    "category": "Point Of Sale",
    "version": "1.0.1",
    "author": "Webkul Software Pvt. Ltd.",
    "license": "Other proprietary",
    "website": "https://store.webkul.com/Odoo-POS-Custom-Discount.html",
    "description": """http://webkul.com/blog/odoo-pos-custom-discount/""",
    "live_test_url": "http://odoodemo.webkul.com/?module=pos_custom_discounts&custom_url=/pos/auto",
    "depends": ['point_of_sale'],
    "demo": ['data/pos_custom_discount_demo.xml'],
    "data": [
        'security/ir.model.access.csv',
        'data/pos_custom_discount_demo.xml',
        'views/res_config_views.xml',
        'views/pos_custom_discounts_view.xml',

    ],

    "images": ['static/description/Banner.png'],
    "application": True,
    "installable": True,
    "assets": {
        'point_of_sale._assets_pos': [
            # "/pos_custom_discounts/static/src/js/main.js",
            "/pos_custom_discounts/static/src/PosDiscountAlertPopup/PosDiscountAlertPopup.js",
            "/pos_custom_discounts/static/src/PosDiscountAlertPopup/PosDiscountAlertPopup.xml",
            "/pos_custom_discounts/static/src/WkDiscountPopup/WkDiscountPopup.js",
            "/pos_custom_discounts/static/src/WkDiscountPopup/WkDiscountPopup.xml",
            "/pos_custom_discounts/static/src/js/pos_store.js",
            "/pos_custom_discounts/static/src/js/PosOrderLine.js",
            "/pos_custom_discounts/static/src/js/ProductScreen.js",
            "/pos_custom_discounts/static/src/js/control_buttons.js",
            "/pos_custom_discounts/static/src/js/PosCustomDiscount.js",
            'pos_custom_discounts/static/src/xml/control_buttons.xml',
            'pos_custom_discounts/static/src/xml/orderline.xml',
            # 'pos_custom_discounts/static/src/xml/pos_custom_discounts.xml',
            "/pos_custom_discounts/static/src/css/pos_custom_discounts.css",
        ],
    },
    "auto_install": False,
    "price": 49,
    "currency": "USD",
}
